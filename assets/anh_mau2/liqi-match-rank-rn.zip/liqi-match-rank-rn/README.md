# Liqi Match – Rank Selection (React Native / Expo)

Màn onboarding chọn rank được dựng lại từ concept Liqi Match theo phong cách dark Douyin, nhưng toàn bộ layout là React Native component thật — không đặt screenshot làm nền.

## Chạy project

```bash
npm install
npx expo start
```

Sau đó nhấn:

- `i` để mở iOS Simulator
- `a` để mở Android Emulator
- hoặc quét QR bằng Expo Go

## Cấu trúc chính

```text
src/screens/RankSelectionScreen.tsx   # màn hình chính
src/components/RankCard.tsx           # card rank có selected state
src/data/ranks.ts                      # dữ liệu 13 mức rank
assets/ranks/*.png                     # huy hiệu rank tách từ concept
assets/design-reference.png            # ảnh tham chiếu thiết kế
```

## Tích hợp với màn login

Thay `Alert` trong nút quay lại / tiếp tục bằng navigation của dự án:

```tsx
navigation.goBack();
navigation.navigate('HeroSetup', { rankId: selectedId });
```

Thiết kế khớp sát nhất trên màn hình khoảng 393–430 px chiều rộng. Layout vẫn responsive và có thể cuộn trên thiết bị thấp hơn.
