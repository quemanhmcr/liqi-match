import { LinearGradient } from 'expo-linear-gradient';
import { useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { RankCard } from '../components/RankCard';
import { ranks, type RankId } from '../data/ranks';
import { colors } from '../theme';

const DESIGN_WIDTH = 393;
const GRID_GAP = 10;

export function RankSelectionScreen() {
  const { width, height } = useWindowDimensions();
  const [selectedId, setSelectedId] = useState<RankId>('master');

  const pagePadding = width < 370 ? 14 : 18;
  const contentWidth = Math.min(width, 430) - pagePadding * 2;
  const cardWidth = Math.floor((contentWidth - GRID_GAP * 2) / 3);
  const uiScale = Math.max(0.9, Math.min(width / DESIGN_WIDTH, 1.08));
  const compactHeight = height < 780;

  const selectedRank = useMemo(
    () => ranks.find((rank) => rank.id === selectedId) ?? ranks[6],
    [selectedId],
  );

  const submit = () => {
    Alert.alert('Đã lưu mức rank', `${selectedRank?.name}${selectedRank?.detail ? ` · ${selectedRank.detail}` : ''}`);
  };

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#080B19', '#030714', '#01040C']}
        locations={[0, 0.42, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.ambientGlow, styles.glowPurple]} />
      <View style={[styles.ambientGlow, styles.glowBlue]} />
      <View style={styles.topVignette} />

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <ScrollView
          bounces={false}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              width: Math.min(width, 430),
              paddingHorizontal: pagePadding,
              paddingBottom: compactHeight ? 20 : 26,
            },
          ]}
        >
          <View style={styles.topBar}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Quay lại"
              onPress={() => Alert.alert('Quay lại', 'Kết nối nút này với màn đăng nhập của bạn.')}
              style={({ pressed }) => [styles.backButton, pressed && styles.controlPressed]}
            >
              <Text style={styles.backGlyph}>‹</Text>
            </Pressable>

            <View style={styles.brandRow} pointerEvents="none">
              <Text style={[styles.brandLiqi, { fontSize: 25 * uiScale }]}>Liqi</Text>
              <Text style={[styles.brandMatch, { fontSize: 25 * uiScale }]}> Match</Text>
            </View>

            <View style={styles.progressPill}>
              <Text style={styles.progressText}>1/3</Text>
              <LinearGradient
                colors={['#AF3FFF', '#684BFF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.progressLine}
              />
            </View>
          </View>

          <View style={[styles.heroCopy, compactHeight && styles.heroCopyCompact]}>
            <Text style={[styles.title, { fontSize: 31 * uiScale }]}>
              Chọn <Text style={styles.titleAccent}>mức rank</Text> hiện tại
            </Text>
            <View style={styles.subtitleRow}>
              <Text style={styles.spark}>✦</Text>
              <Text style={styles.subtitle}>
                Thiết lập hồ sơ ghép đội để hệ thống{`\n`}đề xuất đồng đội phù hợp hơn.
              </Text>
              <Text style={styles.spark}>✦</Text>
            </View>
          </View>

          <View style={[styles.grid, { columnGap: GRID_GAP, rowGap: GRID_GAP }]}> 
            {ranks.map((rank) => (
              <RankCard
                key={rank.id}
                item={rank}
                width={cardWidth}
                selected={rank.id === selectedId}
                onPress={() => setSelectedId(rank.id)}
              />
            ))}
          </View>

          <View style={styles.noteRow}>
            <Text style={styles.infoIcon}>ⓘ</Text>
            <Text style={styles.note}>Bạn có thể thay đổi lại trong Cài đặt sau.</Text>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Tiếp tục"
            onPress={submit}
            style={({ pressed }) => [styles.ctaShell, pressed && styles.ctaPressed]}
          >
            <LinearGradient
              colors={['#B336EC', '#6A3CFF', '#246EFF']}
              locations={[0, 0.52, 1]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={styles.cta}
            >
              <Text style={styles.ctaSpark}>✦</Text>
              <View style={styles.ctaCenter}>
                <Text style={styles.ctaText}>Tiếp tục</Text>
                <View style={styles.arrowBubble}>
                  <Text style={styles.arrow}>→</Text>
                </View>
              </View>
              <Text style={styles.ctaSpark}>✦</Text>
            </LinearGradient>
          </Pressable>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
  },
  safe: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
  },
  scrollContent: {
    flexGrow: 1,
    alignSelf: 'center',
  },
  ambientGlow: {
    position: 'absolute',
    borderRadius: 999,
    opacity: 0.18,
  },
  glowPurple: {
    width: 360,
    height: 360,
    left: -245,
    bottom: 90,
    backgroundColor: '#6B1FFF',
    transform: [{ scaleY: 1.8 }, { rotate: '-10deg' }],
  },
  glowBlue: {
    width: 380,
    height: 380,
    right: -275,
    bottom: -35,
    backgroundColor: '#135DFF',
    transform: [{ scaleY: 1.7 }, { rotate: '14deg' }],
  },
  topVignette: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 200,
    backgroundColor: 'rgba(0,0,0,0.12)',
  },
  topBar: {
    height: 54,
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(17, 23, 43, 0.82)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(145, 154, 192, 0.12)',
  },
  controlPressed: {
    opacity: 0.68,
    transform: [{ scale: 0.96 }],
  },
  backGlyph: {
    color: '#D8DCE9',
    fontSize: 41,
    lineHeight: 42,
    fontWeight: '200',
    marginTop: -4,
  },
  brandRow: {
    position: 'absolute',
    left: 52,
    right: 52,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  brandLiqi: {
    color: '#9D4EFF',
    fontStyle: 'italic',
    fontWeight: '900',
    letterSpacing: -1.2,
    textShadowColor: 'rgba(142, 66, 255, 0.5)',
    textShadowRadius: 8,
  },
  brandMatch: {
    color: '#F5F6FB',
    fontStyle: 'italic',
    fontWeight: '800',
    letterSpacing: -1.2,
  },
  progressPill: {
    width: 52,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16, 21, 42, 0.74)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(126, 136, 178, 0.12)',
  },
  progressText: {
    color: '#C789FF',
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 18,
  },
  progressLine: {
    width: 22,
    height: 2.5,
    borderRadius: 2,
    marginTop: 5,
    shadowColor: colors.violet,
    shadowOpacity: 0.8,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 0 },
  },
  heroCopy: {
    alignItems: 'center',
    marginTop: 34,
    marginBottom: 26,
  },
  heroCopyCompact: {
    marginTop: 24,
    marginBottom: 20,
  },
  title: {
    color: colors.text,
    fontWeight: '800',
    letterSpacing: -1.05,
    textAlign: 'center',
  },
  titleAccent: {
    color: '#A55AFF',
    fontStyle: 'italic',
  },
  subtitleRow: {
    width: '100%',
    marginTop: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  spark: {
    color: '#9740FF',
    fontSize: 16,
    marginHorizontal: 14,
    textShadowColor: '#7B2EFF',
    textShadowRadius: 7,
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    letterSpacing: -0.1,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
  },
  noteRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    marginBottom: 17,
  },
  infoIcon: {
    color: '#9298A9',
    fontSize: 14,
    marginRight: 6,
  },
  note: {
    color: '#7F8597',
    fontSize: 12.5,
  },
  ctaShell: {
    height: 62,
    borderRadius: 31,
    shadowColor: '#654BFF',
    shadowOpacity: 0.54,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 7 },
    elevation: 10,
  },
  ctaPressed: {
    opacity: 0.86,
    transform: [{ scale: 0.985 }],
  },
  cta: {
    flex: 1,
    borderRadius: 31,
    borderWidth: 1,
    borderColor: 'rgba(195, 185, 255, 0.66)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 28,
  },
  ctaCenter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: -0.4,
  },
  arrowBubble: {
    width: 27,
    height: 27,
    borderRadius: 14,
    marginLeft: 10,
    backgroundColor: 'rgba(230, 234, 255, 0.86)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  arrow: {
    color: '#4B57D9',
    fontSize: 19,
    lineHeight: 21,
    fontWeight: '500',
    marginTop: -1,
  },
  ctaSpark: {
    color: 'rgba(220, 215, 255, 0.84)',
    fontSize: 13,
  },
});
