import { LinearGradient } from 'expo-linear-gradient';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import type { RankItem } from '../data/ranks';
import { colors } from '../theme';

type RankCardProps = {
  item: RankItem;
  selected: boolean;
  width: number;
  onPress: () => void;
};

export function RankCard({ item, selected, width, onPress }: RankCardProps) {
  const height = Math.round(width * 0.93);
  const iconHeight = Math.round(Math.min(72, width * 0.61));
  const cardContent = (
    <LinearGradient
      colors={selected ? ['#17103A', '#0D1126'] : ['#0D1329', '#080D1D']}
      locations={[0, 1]}
      style={[styles.inner, { height: selected ? height - 3 : height }]}
    >
      <Image
        source={item.icon}
        resizeMode="contain"
        style={[styles.icon, { width: width * 0.86, height: iconHeight }]}
      />
      <View style={styles.copy}>
        <Text
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.82}
          style={[styles.name, width < 108 && styles.nameCompact]}
        >
          {item.name}
        </Text>
        {item.detail ? (
          <View style={styles.detailRow}>
            <Text style={styles.star}>★</Text>
            <Text
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.82}
              style={styles.detail}
            >
              {item.detail}
            </Text>
          </View>
        ) : null}
      </View>
      {selected ? (
        <View style={styles.checkBubble}>
          <Text style={styles.check}>✓</Text>
        </View>
      ) : null}
    </LinearGradient>
  );

  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ checked: selected }}
      accessibilityLabel={`${item.name}${item.detail ? `, ${item.detail}` : ''}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.pressable,
        { width, height },
        selected && styles.selectedShadow,
        pressed && styles.pressed,
      ]}
    >
      {selected ? (
        <LinearGradient
          colors={['#C750FF', '#7A37FF', '#B03DFF']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.selectedBorder, { width, height }]}
        >
          {cardContent}
        </LinearGradient>
      ) : (
        <View style={[styles.unselectedBorder, { width, height }]}>{cardContent}</View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressable: {
    borderRadius: 16,
  },
  pressed: {
    opacity: 0.84,
    transform: [{ scale: 0.975 }],
  },
  selectedShadow: {
    shadowColor: colors.violet,
    shadowOpacity: 0.78,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 0 },
    elevation: 9,
  },
  selectedBorder: {
    padding: 1.6,
    borderRadius: 17,
  },
  unselectedBorder: {
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  inner: {
    width: '100%',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 6,
    paddingHorizontal: 5,
    overflow: 'hidden',
  },
  icon: {
    marginBottom: -2,
  },
  copy: {
    minHeight: 37,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    paddingHorizontal: 1,
  },
  name: {
    color: colors.text,
    fontSize: 14.5,
    lineHeight: 18,
    fontWeight: '500',
    letterSpacing: -0.25,
    textAlign: 'center',
  },
  nameCompact: {
    fontSize: 13.2,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  star: {
    color: colors.gold,
    fontSize: 11,
    marginRight: 3,
  },
  detail: {
    color: '#BCC0CE',
    fontSize: 11.3,
    lineHeight: 14,
    textAlign: 'center',
  },
  checkBubble: {
    position: 'absolute',
    top: 7,
    right: 7,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#8750FF',
    shadowColor: '#B65CFF',
    shadowOpacity: 0.75,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 0 },
  },
  check: {
    color: '#12082A',
    fontSize: 15,
    lineHeight: 18,
    fontWeight: '900',
  },
});
