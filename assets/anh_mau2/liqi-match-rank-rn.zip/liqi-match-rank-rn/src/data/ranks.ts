import type { ImageSourcePropType } from 'react-native';

export type RankId =
  | 'bronze'
  | 'silver'
  | 'gold'
  | 'platinum'
  | 'diamond'
  | 'veteran'
  | 'master'
  | 'grandmaster-iv'
  | 'grandmaster-iii'
  | 'grandmaster-ii'
  | 'grandmaster-i'
  | 'conqueror'
  | 'legendary';

export type RankItem = {
  id: RankId;
  name: string;
  detail?: string;
  icon: ImageSourcePropType;
};

export const ranks: RankItem[] = [
  { id: 'bronze', name: 'Đồng', icon: require('../../assets/ranks/bronze.png') },
  { id: 'silver', name: 'Bạc', icon: require('../../assets/ranks/silver.png') },
  { id: 'gold', name: 'Vàng', icon: require('../../assets/ranks/gold.png') },
  { id: 'platinum', name: 'Bạch Kim', icon: require('../../assets/ranks/platinum.png') },
  { id: 'diamond', name: 'Kim Cương', icon: require('../../assets/ranks/diamond.png') },
  { id: 'veteran', name: 'Tinh Anh', icon: require('../../assets/ranks/veteran.png') },
  { id: 'master', name: 'Cao Thủ', icon: require('../../assets/ranks/master.png') },
  {
    id: 'grandmaster-iv',
    name: 'Đại Cao Thủ IV',
    detail: '10–19 sao',
    icon: require('../../assets/ranks/grandmaster-iv.png'),
  },
  {
    id: 'grandmaster-iii',
    name: 'Đại Cao Thủ III',
    detail: '20–29 sao',
    icon: require('../../assets/ranks/grandmaster-iii.png'),
  },
  {
    id: 'grandmaster-ii',
    name: 'Đại Cao Thủ II',
    detail: '30–39 sao',
    icon: require('../../assets/ranks/grandmaster-ii.png'),
  },
  {
    id: 'grandmaster-i',
    name: 'Đại Cao Thủ I',
    detail: '40–49 sao',
    icon: require('../../assets/ranks/grandmaster-i.png'),
  },
  {
    id: 'conqueror',
    name: 'Chiến Tướng',
    detail: '50–99 sao',
    icon: require('../../assets/ranks/conqueror.png'),
  },
  {
    id: 'legendary',
    name: 'Chiến Thần',
    detail: '100+ sao',
    icon: require('../../assets/ranks/legendary.png'),
  },
];
