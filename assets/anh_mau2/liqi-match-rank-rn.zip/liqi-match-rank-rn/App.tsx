import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { RankSelectionScreen } from './src/screens/RankSelectionScreen';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <RankSelectionScreen />
    </SafeAreaProvider>
  );
}
