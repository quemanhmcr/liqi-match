import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';

type SocialOptionProps = {
  kind: 'chat' | 'apple' | 'phone';
  label: string;
  onPress: () => void;
};

function SocialGlyph({ kind }: Pick<SocialOptionProps, 'kind'>) {
  if (kind === 'chat') {
    return (
      <View style={[styles.circle, styles.chatCircle]}>
        <View style={styles.chatBubbleA}><Text style={styles.chatDots}>••</Text></View>
        <View style={styles.chatBubbleB} />
      </View>
    );
  }

  if (kind === 'apple') {
    return (
      <View style={[styles.circle, styles.appleCircle]}>
        <Text style={styles.appleGlyph}>●</Text>
        <View style={styles.appleLeaf} />
      </View>
    );
  }

  return (
    <View style={[styles.circle, styles.phoneCircle]}>
      <View style={styles.phoneBody}><View style={styles.phoneHome} /></View>
    </View>
  );
}

export function SocialOption({ kind, label, onPress }: SocialOptionProps) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.wrapper, pressed && styles.pressed]}
    >
      <SocialGlyph kind={kind} />
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: { alignItems: 'center', width: 92 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.97 }] },
  circle: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  chatCircle: {
    backgroundColor: 'rgba(36, 139, 83, 0.13)',
    borderColor: 'rgba(75, 207, 127, 0.22)',
  },
  appleCircle: {
    backgroundColor: 'rgba(255,255,255,0.055)',
    borderColor: 'rgba(255,255,255,0.13)',
  },
  phoneCircle: {
    backgroundColor: 'rgba(113, 55, 255, 0.12)',
    borderColor: 'rgba(147, 87, 255, 0.22)',
  },
  chatBubbleA: {
    width: 23,
    height: 17,
    borderRadius: 10,
    backgroundColor: '#4BD87A',
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ translateX: -3 }, { translateY: -2 }],
  },
  chatBubbleB: {
    position: 'absolute',
    width: 18,
    height: 14,
    borderRadius: 8,
    backgroundColor: '#3CBF69',
    right: 11,
    bottom: 11,
  },
  chatDots: { color: '#052E16', fontWeight: '900', fontSize: 8, marginTop: -3 },
  appleGlyph: { color: '#FFFFFF', fontSize: 31, lineHeight: 33, transform: [{ scaleX: 0.86 }] },
  appleLeaf: {
    position: 'absolute',
    width: 7,
    height: 4,
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
    top: 11,
    right: 19,
    transform: [{ rotate: '-28deg' }],
  },
  phoneBody: {
    width: 17,
    height: 27,
    borderRadius: 3,
    borderWidth: 2,
    borderColor: '#9664FF',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 2,
  },
  phoneHome: { width: 4, height: 2, borderRadius: 1, backgroundColor: '#9664FF' },
  label: { color: '#A5ABBC', fontSize: 12, marginTop: 10 },
});
