import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';

type FeatureItemProps = {
  icon: 'shield' | 'mic' | 'target';
  title: string;
  subtitle: string;
  showDivider?: boolean;
};

function FeatureIcon({ type }: { type: FeatureItemProps['icon'] }) {
  if (type === 'mic') {
    return (
      <View style={styles.iconShell}>
        <View style={styles.micCapsule} />
        <View style={styles.micStem} />
        <View style={styles.micBase} />
      </View>
    );
  }

  if (type === 'target') {
    return (
      <View style={styles.iconShell}>
        <View style={styles.targetOuter}>
          <View style={styles.targetInner}>
            <View style={styles.targetDot} />
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.iconShell}>
      <View style={styles.shield}>
        <Text style={styles.check}>✓</Text>
      </View>
    </View>
  );
}

export function FeatureItem({ icon, title, subtitle, showDivider }: FeatureItemProps) {
  return (
    <View style={styles.wrapper}>
      {showDivider ? <View style={styles.divider} /> : null}
      <FeatureIcon type={icon} />
      <View style={styles.copy}>
        <Text numberOfLines={1} style={styles.title}>{title}</Text>
        <Text numberOfLines={1} style={styles.subtitle}>{subtitle}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    position: 'relative',
  },
  divider: {
    position: 'absolute',
    left: 0,
    top: 8,
    bottom: 8,
    width: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(151, 162, 195, 0.18)',
  },
  iconShell: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 7,
    backgroundColor: 'rgba(113, 55, 255, 0.12)',
    shadowColor: colors.violet,
    shadowOpacity: 0.7,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
  copy: { flex: 1, minWidth: 0 },
  title: {
    color: colors.text,
    fontSize: 12.5,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  subtitle: {
    color: colors.muted,
    fontSize: 9.5,
    marginTop: 3,
  },
  shield: {
    width: 20,
    height: 23,
    borderWidth: 1.7,
    borderColor: '#7257FF',
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
    borderBottomLeftRadius: 9,
    borderBottomRightRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ scaleX: 0.92 }],
  },
  check: { color: '#A99BFF', fontSize: 11, fontWeight: '900', marginTop: -1 },
  micCapsule: {
    width: 9,
    height: 17,
    borderRadius: 6,
    borderWidth: 1.7,
    borderColor: '#9B56FF',
  },
  micStem: { width: 1.7, height: 6, backgroundColor: '#9B56FF' },
  micBase: { width: 12, height: 1.7, borderRadius: 1, backgroundColor: '#9B56FF' },
  targetOuter: {
    width: 23,
    height: 23,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#5C72FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  targetInner: {
    width: 13,
    height: 13,
    borderRadius: 7,
    borderWidth: 1.5,
    borderColor: '#7E49FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  targetDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: '#A966FF' },
});
