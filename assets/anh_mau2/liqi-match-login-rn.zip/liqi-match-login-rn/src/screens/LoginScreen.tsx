import { LinearGradient } from 'expo-linear-gradient';
import { useMemo, useState } from 'react';
import {
  Alert,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FeatureItem } from '../components/FeatureItem';
import { SocialOption } from '../components/SocialOption';
import { colors } from '../theme';

const BASE_WIDTH = 393;

export function LoginScreen() {
  const { width, height } = useWindowDimensions();
  const [phone, setPhone] = useState('');
  const [accepted, setAccepted] = useState(false);

  const scale = useMemo(() => Math.max(0.88, Math.min(width / BASE_WIDTH, 1.08)), [width]);
  const horizontal = 18 * scale;
  const compact = height < 790;

  const handleLogin = () => {
    if (!accepted) {
      Alert.alert('Agreement required', 'Please accept the User Agreement and Privacy Policy.');
      return;
    }
    if (phone.replace(/\D/g, '').length < 7) {
      Alert.alert('Invalid phone number', 'Please enter a valid phone number.');
      return;
    }
    Alert.alert('Verification code sent', `A code has been sent to +86 ${phone}.`);
  };

  const social = (name: string) => Alert.alert(name, `${name} authentication can be connected here.`);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#050817', '#020611', '#01040B']}
        locations={[0, 0.48, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.glow, styles.glowLeft]} />
      <View style={[styles.glow, styles.glowRight]} />

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.flex}
        >
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={[
              styles.content,
              { paddingHorizontal: horizontal, paddingBottom: compact ? 18 : 24 },
            ]}
            showsVerticalScrollIndicator={false}
            bounces={false}
          >
            <View style={[styles.brandBlock, compact && styles.brandBlockCompact]}>
              <View style={styles.logoRow}>
                <Text style={[styles.logoLiqi, { fontSize: 39 * scale }]}>Liqi</Text>
                <Text style={[styles.logoMatch, { fontSize: 39 * scale }]}> Match</Text>
              </View>
              <View style={styles.taglineRow}>
                <LinearGradient colors={['#A53DFF', '#3E67FF']} style={styles.taglineDash} />
                <Text style={styles.tagline}>精准匹配，轻松上分</Text>
                <LinearGradient colors={['#3E67FF', '#D237FF']} style={styles.taglineDash} />
              </View>
            </View>

            <View style={styles.heroFrame}>
              <ImageBackground
                source={require('../../assets/liqi-login-hero.png')}
                resizeMode="cover"
                style={styles.hero}
                imageStyle={styles.heroImage}
              >
                <LinearGradient
                  colors={['rgba(2,6,17,0.04)', 'rgba(2,6,17,0)', 'rgba(2,6,17,0.36)']}
                  locations={[0, 0.67, 1]}
                  style={StyleSheet.absoluteFill}
                />
              </ImageBackground>
            </View>

            <View style={styles.featureCard}>
              <FeatureItem icon="shield" title="真实玩家" subtitle="真人认证" />
              <FeatureItem icon="mic" title="语音开黑" subtitle="实时沟通" showDivider />
              <FeatureItem icon="target" title="智能匹配" subtitle="实力更均衡" showDivider />
            </View>

            <View style={styles.phoneField}>
              <Pressable style={styles.countryCode}>
                <Text style={styles.countryText}>+86</Text>
                <Text style={styles.chevron}>⌄</Text>
              </Pressable>
              <View style={styles.fieldDivider} />
              <TextInput
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                placeholder="请输入手机号"
                placeholderTextColor="#6F778C"
                style={styles.input}
                selectionColor="#9954FF"
                maxLength={18}
                accessibilityLabel="Phone number"
              />
              <Pressable onPress={handleLogin} hitSlop={10}>
                <Text style={styles.codeText}>获取验证码</Text>
              </Pressable>
            </View>

            <Pressable
              onPress={handleLogin}
              accessibilityRole="button"
              style={({ pressed }) => [styles.loginButtonWrap, pressed && styles.buttonPressed]}
            >
              <LinearGradient
                colors={['#B22EFF', '#6A43FF', '#1767FF']}
                start={{ x: 0, y: 0.4 }}
                end={{ x: 1, y: 0.6 }}
                style={styles.loginButton}
              >
                <Text style={styles.sparkle}>✦</Text>
                <View style={styles.loginCenter}>
                  <Text style={styles.loginText}>立即登录</Text>
                  <View style={styles.arrowBadge}><Text style={styles.arrow}>→</Text></View>
                </View>
                <Text style={styles.sparkle}>✦</Text>
              </LinearGradient>
            </Pressable>

            <View style={styles.separatorRow}>
              <View style={styles.separator} />
              <Text style={styles.separatorText}>其他登录方式</Text>
              <View style={styles.separator} />
            </View>

            <View style={styles.socialRow}>
              <SocialOption kind="chat" label="微信登录" onPress={() => social('Chat login')} />
              <SocialOption kind="apple" label="Apple 登录" onPress={() => social('Apple login')} />
              <SocialOption kind="phone" label="手机号登录" onPress={() => social('Phone login')} />
            </View>

            <Pressable
              onPress={() => setAccepted((value) => !value)}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: accepted }}
              style={styles.agreementRow}
            >
              <View style={[styles.checkbox, accepted && styles.checkboxChecked]}>
                {accepted ? <Text style={styles.checkboxTick}>✓</Text> : null}
              </View>
              <Text style={styles.agreementText}>我已阅读并同意 </Text>
              <Text style={styles.agreementLink}>《用户协议》</Text>
              <Text style={styles.agreementText}> 与 </Text>
              <Text style={styles.agreementLink}>《隐私政策》</Text>
            </Pressable>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background, overflow: 'hidden' },
  safe: { flex: 1 },
  flex: { flex: 1 },
  content: { flexGrow: 1, alignItems: 'stretch' },
  glow: {
    position: 'absolute',
    width: 380,
    height: 380,
    borderRadius: 190,
    opacity: 0.16,
    transform: [{ scaleY: 0.42 }, { rotate: '-18deg' }],
  },
  glowLeft: { left: -270, bottom: 90, backgroundColor: '#762CFF' },
  glowRight: { right: -290, bottom: 250, backgroundColor: '#2258FF' },
  brandBlock: { alignItems: 'center', marginTop: 20, marginBottom: 14 },
  brandBlockCompact: { marginTop: 8, marginBottom: 9 },
  logoRow: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'center' },
  logoLiqi: {
    color: '#A23CFF',
    fontWeight: '900',
    fontStyle: 'italic',
    letterSpacing: -2.2,
    textShadowColor: 'rgba(95, 66, 255, 0.55)',
    textShadowRadius: 15,
    textShadowOffset: { width: 0, height: 0 },
    transform: [{ skewX: '-7deg' }],
  },
  logoMatch: {
    color: '#F8F8FC',
    fontWeight: '900',
    fontStyle: 'italic',
    letterSpacing: -2.3,
    transform: [{ skewX: '-7deg' }],
  },
  taglineRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  tagline: { color: '#C0C3CF', fontSize: 13, letterSpacing: 3.2, marginHorizontal: 11 },
  taglineDash: { width: 13, height: 2, borderRadius: 2 },
  heroFrame: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(87, 89, 151, 0.10)',
    backgroundColor: '#080C1C',
  },
  hero: { width: '100%', aspectRatio: 548 / 440, justifyContent: 'flex-end' },
  heroImage: { borderRadius: 18 },
  featureCard: {
    minHeight: 76,
    marginTop: 8,
    borderRadius: 17,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(11, 17, 32, 0.94)',
    flexDirection: 'row',
    paddingHorizontal: 8,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
  },
  phoneField: {
    height: 58,
    marginTop: 23,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    backgroundColor: 'rgba(9, 14, 27, 0.92)',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  countryCode: { flexDirection: 'row', alignItems: 'center', height: '100%' },
  countryText: { color: '#F0F2F8', fontSize: 15.5, fontWeight: '500' },
  chevron: { color: '#858DA1', marginLeft: 8, fontSize: 16, marginTop: -4 },
  fieldDivider: { width: StyleSheet.hairlineWidth, height: 24, marginHorizontal: 13, backgroundColor: '#343B4D' },
  input: { flex: 1, height: '100%', color: colors.text, fontSize: 15.5, paddingVertical: 0 },
  codeText: { color: '#7764FF', fontSize: 14.5, fontWeight: '600' },
  loginButtonWrap: {
    marginTop: 22,
    borderRadius: 30,
    shadowColor: '#5E38FF',
    shadowOpacity: 0.62,
    shadowRadius: 22,
    shadowOffset: { width: 0, height: 10 },
    elevation: 12,
  },
  buttonPressed: { opacity: 0.9, transform: [{ scale: 0.992 }] },
  loginButton: {
    height: 59,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.34)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 19,
  },
  loginCenter: { flexDirection: 'row', alignItems: 'center' },
  loginText: { color: '#FFFFFF', fontSize: 19, fontWeight: '800', letterSpacing: 0.4 },
  arrowBadge: {
    width: 27,
    height: 27,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.78)',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 11,
  },
  arrow: { color: '#5A4DDA', fontSize: 18, lineHeight: 20, fontWeight: '800', marginTop: -1 },
  sparkle: { color: 'rgba(255,255,255,0.68)', fontSize: 13 },
  separatorRow: { flexDirection: 'row', alignItems: 'center', marginTop: 26, marginBottom: 18 },
  separator: { flex: 1, height: StyleSheet.hairlineWidth, backgroundColor: 'rgba(116,124,147,0.20)' },
  separatorText: { marginHorizontal: 16, color: '#757D90', fontSize: 12.5 },
  socialRow: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'flex-start' },
  agreementRow: {
    marginTop: 22,
    minHeight: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
    paddingHorizontal: 5,
  },
  checkbox: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#5D6577',
    marginRight: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: { backgroundColor: '#7444FF', borderColor: '#9A75FF' },
  checkboxTick: { color: '#FFFFFF', fontSize: 10, fontWeight: '900' },
  agreementText: { color: '#7B8395', fontSize: 11.5 },
  agreementLink: { color: '#8B55FF', fontSize: 11.5 },
});
