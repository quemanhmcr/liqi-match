# Liqi Match — React Native login screen

A functional Expo / React Native implementation of the generated Liqi Match login concept. The UI is built from native components; the generic MOBA hero artwork is the only raster asset.

## Run

```bash
npm install
npx expo start
```

Then open the QR code in Expo Go, or press `i` / `a` for an iOS simulator or Android emulator.

## Important files

- `src/screens/LoginScreen.tsx` — complete responsive login screen
- `src/components/FeatureItem.tsx` — three value-proposition cells
- `src/components/SocialOption.tsx` — reusable social login button
- `assets/liqi-login-hero.png` — generated generic hero artwork cropped from the approved concept

## Integration notes

Replace the `Alert` handlers with your OTP/authentication APIs. The agreement checkbox and phone validation are already wired.
