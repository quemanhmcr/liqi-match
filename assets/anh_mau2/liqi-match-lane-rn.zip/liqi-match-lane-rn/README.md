# Liqi Match — Lane Selection

Màn onboarding bước 2/3 cho phép chọn tối đa hai vị trí trong Liên Quân Mobile.

## Chạy project

```bash
npm install
npx expo start
```

## Tính năng

- Dark Douyin-inspired visual system đồng bộ màn chọn rank.
- 5 lane: Đường Tà Thần, Đi Rừng, Đường Giữa, Đường Rồng, Trợ Thủ.
- Chọn tối đa 2 lane; lane đầu tiên là vị trí ưu tiên.
- Responsive cho điện thoại 360–430 px.
- Component thật, hỗ trợ tương tác và accessibility state.

## File chính

- `src/screens/LaneSelectionScreen.tsx`
- `src/components/LaneCard.tsx`
- `src/data/lanes.ts`
