import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { Lane } from '../data/lanes';

export function LaneCard({
  item,
  selected,
  primary,
  onPress,
}: {
  item: Lane;
  selected: boolean;
  primary: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [styles.pressable, pressed && styles.pressed]}
    >
      <LinearGradient
        colors={selected ? ['rgba(105,57,223,0.40)', 'rgba(19,26,52,0.98)'] : ['rgba(18,24,45,0.94)', 'rgba(8,13,28,0.98)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.card, selected && styles.cardSelected]}
      >
        <View style={[styles.iconWrap, selected && { borderColor: item.accent[0] }]}>
          <LinearGradient colors={item.accent} style={styles.iconGradient}>
            <MaterialCommunityIcons name={item.icon} size={31} color="#FFFFFF" />
          </LinearGradient>
        </View>

        <View style={styles.copy}>
          <View style={styles.titleRow}>
            <Text style={styles.name}>{item.name}</Text>
            {primary && (
              <View style={styles.primaryPill}>
                <Text style={styles.primaryText}>Ưu tiên</Text>
              </View>
            )}
          </View>
          <Text style={styles.subtitle}>{item.subtitle}</Text>
        </View>

        <View style={[styles.checkbox, selected && styles.checkboxSelected]}>
          {selected && <MaterialCommunityIcons name="check" size={18} color="#FFFFFF" />}
        </View>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressable: { width: '100%' },
  pressed: { opacity: 0.82, transform: [{ scale: 0.988 }] },
  card: {
    minHeight: 92,
    borderRadius: 22,
    paddingHorizontal: 15,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(134,148,190,0.14)',
    shadowColor: '#000000',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 5,
  },
  cardSelected: {
    borderColor: '#8C58FF',
    shadowColor: '#7739FF',
    shadowOpacity: 0.48,
    shadowRadius: 18,
    elevation: 9,
  },
  iconWrap: {
    width: 60,
    height: 60,
    borderRadius: 19,
    padding: 1,
    borderWidth: 1,
    borderColor: 'rgba(150,160,196,0.14)',
    backgroundColor: '#0D1328',
  },
  iconGradient: {
    flex: 1,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  copy: { flex: 1, marginLeft: 14 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { color: '#F6F7FD', fontSize: 17, fontWeight: '700', letterSpacing: -0.25 },
  subtitle: { color: '#8D96AE', fontSize: 12.5, marginTop: 6 },
  primaryPill: {
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: 'rgba(161,73,255,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(185,105,255,0.35)',
  },
  primaryText: { color: '#D5A7FF', fontSize: 10.5, fontWeight: '700' },
  checkbox: {
    width: 27,
    height: 27,
    borderRadius: 13.5,
    borderWidth: 1,
    borderColor: 'rgba(160,170,204,0.32)',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 10,
  },
  checkboxSelected: { backgroundColor: '#7F46F5', borderColor: '#B985FF' },
});
