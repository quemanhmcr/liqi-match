import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LaneCard } from '../components/LaneCard';
import { lanes, type LaneId } from '../data/lanes';

const MAX_SELECTIONS = 2;

export function LaneSelectionScreen() {
  const { width, height } = useWindowDimensions();
  const [selected, setSelected] = useState<LaneId[]>(['jungle']);
  const pageWidth = Math.min(width, 430);
  const compact = height < 760;

  const selectedNames = useMemo(
    () => selected.map((id) => lanes.find((lane) => lane.id === id)?.name).filter(Boolean),
    [selected],
  );

  const toggleLane = (id: LaneId) => {
    setSelected((current) => {
      if (current.includes(id)) {
        return current.length === 1 ? current : current.filter((item) => item !== id);
      }
      if (current.length >= MAX_SELECTIONS) return [current[0]!, id];
      return [...current, id];
    });
  };

  return (
    <View style={styles.root}>
      <LinearGradient colors={['#090B1A', '#040817', '#01040C']} locations={[0, 0.48, 1]} style={StyleSheet.absoluteFill} />
      <View style={[styles.glow, styles.glowLeft]} />
      <View style={[styles.glow, styles.glowRight]} />

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <ScrollView
          bounces={false}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.content, { width: pageWidth, paddingHorizontal: width < 370 ? 15 : 19 }]}
        >
          <View style={styles.topBar}>
            <Pressable onPress={() => Alert.alert('Quay lại')} style={({ pressed }) => [styles.circleButton, pressed && styles.pressed]}>
              <MaterialCommunityIcons name="chevron-left" size={31} color="#DCE0EE" />
            </Pressable>

            <View style={styles.brand}>
              <Text style={styles.brandLiqi}>Liqi</Text>
              <Text style={styles.brandMatch}> Match</Text>
            </View>

            <View style={styles.progressPill}>
              <Text style={styles.progressText}>2/3</Text>
              <View style={styles.progressTrack}>
                <LinearGradient colors={['#B63DFF', '#546BFF']} style={styles.progressFill} />
              </View>
            </View>
          </View>

          <View style={[styles.heading, compact && styles.headingCompact]}>
            <Text style={styles.eyebrow}>VỊ TRÍ SỞ TRƯỜNG</Text>
            <Text style={styles.title}>Bạn thường chơi ở <Text style={styles.titleAccent}>lane nào?</Text></Text>
            <Text style={styles.subtitle}>Chọn tối đa 2 vị trí. Vị trí đầu tiên sẽ được ưu tiên khi hệ thống ghép đội.</Text>
          </View>

          <View style={styles.tipCard}>
            <View style={styles.tipIcon}>
              <MaterialCommunityIcons name="auto-fix" size={19} color="#D9B4FF" />
            </View>
            <Text style={styles.tipText}>Ghép đúng vai trò giúp đội hình cân bằng và giảm tranh lane.</Text>
          </View>

          <View style={[styles.list, compact && styles.listCompact]}>
            {lanes.map((lane) => (
              <LaneCard
                key={lane.id}
                item={lane}
                selected={selected.includes(lane.id)}
                primary={selected[0] === lane.id}
                onPress={() => toggleLane(lane.id)}
              />
            ))}
          </View>

          <View style={styles.selectionSummary}>
            <View>
              <Text style={styles.summaryLabel}>Đã chọn</Text>
              <Text style={styles.summaryValue}>{selectedNames.join(' · ')}</Text>
            </View>
            <Text style={styles.count}>{selected.length}/{MAX_SELECTIONS}</Text>
          </View>

          <Pressable
            onPress={() => Alert.alert('Đã lưu vị trí', selectedNames.join(' · '))}
            style={({ pressed }) => [styles.ctaShell, pressed && styles.ctaPressed]}
          >
            <LinearGradient colors={['#B632EC', '#6742FF', '#236EFF']} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={styles.cta}>
              <Text style={styles.spark}>✦</Text>
              <View style={styles.ctaCenter}>
                <Text style={styles.ctaText}>Tiếp tục</Text>
                <View style={styles.arrowBubble}><MaterialCommunityIcons name="arrow-right" size={21} color="#5060E9" /></View>
              </View>
              <Text style={styles.spark}>✦</Text>
            </LinearGradient>
          </Pressable>

          <Text style={styles.footnote}>Bạn có thể thay đổi lại trong Cài đặt sau.</Text>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#02050E', alignItems: 'center' },
  safe: { flex: 1, width: '100%', alignItems: 'center' },
  content: { flexGrow: 1, alignSelf: 'center', paddingBottom: 18 },
  glow: { position: 'absolute', width: 360, height: 360, borderRadius: 999, opacity: 0.17 },
  glowLeft: { left: -270, bottom: 65, backgroundColor: '#7822FF', transform: [{ scaleY: 1.7 }] },
  glowRight: { right: -280, bottom: -50, backgroundColor: '#176BFF', transform: [{ scaleY: 1.55 }] },
  topBar: { height: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  circleButton: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(17,23,43,0.84)', borderWidth: 1, borderColor: 'rgba(150,160,195,0.10)' },
  pressed: { opacity: 0.7, transform: [{ scale: 0.96 }] },
  brand: { flexDirection: 'row', alignItems: 'center' },
  brandLiqi: { fontSize: 25, fontWeight: '900', fontStyle: 'italic', color: '#9A4FFF', letterSpacing: -1 },
  brandMatch: { fontSize: 25, fontWeight: '900', fontStyle: 'italic', color: '#F6F7FB', letterSpacing: -1 },
  progressPill: { width: 66, height: 46, borderRadius: 23, backgroundColor: 'rgba(17,23,43,0.84)', alignItems: 'center', justifyContent: 'center' },
  progressText: { color: '#C99AFF', fontWeight: '800', fontSize: 16 },
  progressTrack: { width: 38, height: 3, borderRadius: 2, backgroundColor: '#282E48', marginTop: 6, overflow: 'hidden' },
  progressFill: { width: 25, height: '100%', borderRadius: 2 },
  heading: { marginTop: 30, marginBottom: 20 },
  headingCompact: { marginTop: 18, marginBottom: 14 },
  eyebrow: { color: '#8F70D8', fontSize: 11, fontWeight: '800', letterSpacing: 2.1, marginBottom: 10 },
  title: { color: '#F7F8FD', fontSize: 31, lineHeight: 38, fontWeight: '900', letterSpacing: -1.1 },
  titleAccent: { color: '#9C61FF', fontStyle: 'italic' },
  subtitle: { color: '#9299AD', fontSize: 14.5, lineHeight: 21, marginTop: 11, maxWidth: 350 },
  tipCard: { minHeight: 54, borderRadius: 18, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(79,43,145,0.13)', borderWidth: 1, borderColor: 'rgba(157,91,255,0.20)', marginBottom: 14 },
  tipIcon: { width: 32, height: 32, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(148,72,255,0.16)', marginRight: 10 },
  tipText: { flex: 1, color: '#B9BFD0', fontSize: 12.5, lineHeight: 18 },
  list: { gap: 11 },
  listCompact: { gap: 8 },
  selectionSummary: { marginTop: 14, marginBottom: 12, borderRadius: 18, paddingHorizontal: 15, paddingVertical: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'rgba(12,18,35,0.90)', borderWidth: 1, borderColor: 'rgba(131,144,180,0.13)' },
  summaryLabel: { color: '#777F96', fontSize: 11.5 },
  summaryValue: { color: '#E8EAF3', fontSize: 13.5, fontWeight: '700', marginTop: 4 },
  count: { color: '#B287FF', fontSize: 15, fontWeight: '800' },
  ctaShell: { borderRadius: 25, shadowColor: '#743BFF', shadowOpacity: 0.55, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 10 },
  ctaPressed: { opacity: 0.86, transform: [{ scale: 0.99 }] },
  cta: { height: 58, borderRadius: 25, paddingHorizontal: 24, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: 'rgba(207,184,255,0.43)' },
  ctaCenter: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  ctaText: { color: '#FFFFFF', fontSize: 19, fontWeight: '800' },
  arrowBubble: { width: 31, height: 31, borderRadius: 15.5, backgroundColor: 'rgba(246,248,255,0.88)', alignItems: 'center', justifyContent: 'center' },
  spark: { color: 'rgba(255,255,255,0.72)', fontSize: 13 },
  footnote: { textAlign: 'center', color: '#626A80', fontSize: 11.5, marginTop: 12 },
});
