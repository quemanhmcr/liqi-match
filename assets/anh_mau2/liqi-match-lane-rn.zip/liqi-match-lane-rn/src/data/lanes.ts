export type LaneId = 'slayer' | 'jungle' | 'mid' | 'dragon' | 'support';

export type Lane = {
  id: LaneId;
  name: string;
  subtitle: string;
  icon: 'sword-cross' | 'pine-tree' | 'creation' | 'target' | 'shield-star';
  accent: [string, string];
};

export const lanes: Lane[] = [
  {
    id: 'slayer',
    name: 'Đường Tà Thần',
    subtitle: 'Đấu sĩ · chống chịu',
    icon: 'sword-cross',
    accent: ['#B980FF', '#6D4AFF'],
  },
  {
    id: 'jungle',
    name: 'Đi Rừng',
    subtitle: 'Kiểm soát · tạo đột biến',
    icon: 'pine-tree',
    accent: ['#45E6C5', '#158E8D'],
  },
  {
    id: 'mid',
    name: 'Đường Giữa',
    subtitle: 'Pháp sư · đảo đường',
    icon: 'creation',
    accent: ['#75B8FF', '#5364FF'],
  },
  {
    id: 'dragon',
    name: 'Đường Rồng',
    subtitle: 'Xạ thủ · sát thương chủ lực',
    icon: 'target',
    accent: ['#FF7FC6', '#D94B8E'],
  },
  {
    id: 'support',
    name: 'Trợ Thủ',
    subtitle: 'Bảo kê · mở giao tranh',
    icon: 'shield-star',
    accent: ['#FFC970', '#D98A36'],
  },
];
