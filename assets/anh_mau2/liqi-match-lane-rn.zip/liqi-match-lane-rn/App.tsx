import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { LaneSelectionScreen } from './src/screens/LaneSelectionScreen';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <LaneSelectionScreen />
    </SafeAreaProvider>
  );
}
