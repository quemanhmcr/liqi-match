LIÊN QUÂN MOBILE — BỘ ẢNH TƯỚNG CẬP NHẬT 2026

Tổng số ảnh/card: 128
Tổng số tên tướng duy nhất: 127

Bổ sung so với bộ 125 cũ:
- Flowborn — biến thể Xạ Thủ
- Flowborn Phép — biến thể Pháp Sư
- Dyadia — Trợ Thủ / Pháp Sư

Lưu ý: Flowborn là một tướng đa lớp nhưng được giao diện danh mục hiện tại biểu diễn thành hai biến thể, nên bộ này có 128 ảnh lựa chọn và 127 tên tướng duy nhất.

Thư mục heroes/ chứa toàn bộ ảnh 100x100. manifest.json và heroes.csv chứa tên, file, biến thể, URL nguồn, kích thước và SHA-256.

Ảnh chân dung được lấy từ AOV Builds, nguồn độc lập không thuộc Garena. Hãy kiểm tra quyền sử dụng trước khi phát hành thương mại.
