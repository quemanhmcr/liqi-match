import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GalleryTile } from '../components/GalleryTile';
import { GradientButton } from '../components/GradientButton';
import { Snackbar } from '../components/Snackbar';
import { SourcePickerSheet } from '../components/SourcePickerSheet';
import { StatusPill } from '../components/StatusPill';
import { colors } from '../theme/colors';

type MediaKind = 'avatar' | 'cover' | 'wall';
type MediaStatus = 'processing' | 'ready';
type MediaItem = { uri: string; status: MediaStatus };
type SourceRequest = { kind: MediaKind; index?: number } | null;
type InlineError = { kind: MediaKind; index?: number; message: string } | null;
type SnackbarState = {
  message: string;
  tone?: 'neutral' | 'success' | 'error';
  actionLabel?: string;
  onAction?: () => void;
} | null;

type StoredDraft = {
  avatarUri: string | null;
  coverUri: string | null;
  wallUris: Array<string | null>;
};

const DRAFT_KEY = '@liqi-match/profile-media-draft-v2';
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const PROCESSING_DELAY_MS = 420;

export default function ProfileMediaScreen() {
  const { width } = useWindowDimensions();
  const compact = width < 390;
  const contentWidth = useMemo(() => Math.min(width, 760), [width]);

  const [avatar, setAvatar] = useState<MediaItem | null>(null);
  const [cover, setCover] = useState<MediaItem | null>(null);
  const [wallItems, setWallItems] = useState<Array<MediaItem | null>>([null, null, null, null]);
  const [sourceRequest, setSourceRequest] = useState<SourceRequest>(null);
  const [inlineError, setInlineError] = useState<InlineError>(null);
  const [galleryExpanded, setGalleryExpanded] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [snackbar, setSnackbar] = useState<SnackbarState>(null);
  const snackbarTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const wallCount = wallItems.filter(Boolean).length;
  const mediaCount = Number(Boolean(avatar)) + Number(Boolean(cover)) + wallCount;

  useEffect(() => {
    let active = true;

    async function restoreDraft() {
      try {
        const rawDraft = await AsyncStorage.getItem(DRAFT_KEY);
        if (!active || !rawDraft) return;
        const draft = JSON.parse(rawDraft) as StoredDraft;
        setAvatar(draft.avatarUri ? { uri: draft.avatarUri, status: 'ready' } : null);
        setCover(draft.coverUri ? { uri: draft.coverUri, status: 'ready' } : null);
        setWallItems(
          Array.from({ length: 4 }, (_, index) => {
            const uri = draft.wallUris?.[index];
            return uri ? { uri, status: 'ready' as const } : null;
          }),
        );
        if (draft.wallUris?.some(Boolean)) setGalleryExpanded(true);
      } catch {
        showSnackbar('Không thể khôi phục bản nháp trước đó.', 'error');
      } finally {
        if (active) setHydrated(true);
      }
    }

    restoreDraft();
    return () => {
      active = false;
      if (snackbarTimer.current) clearTimeout(snackbarTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const draft: StoredDraft = {
      avatarUri: avatar?.uri ?? null,
      coverUri: cover?.uri ?? null,
      wallUris: wallItems.map((item) => item?.uri ?? null),
    };
    AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft)).catch(() => {
      showSnackbar('Không thể tự động lưu bản nháp.', 'error');
    });
  }, [avatar, cover, hydrated, wallItems]);

  function showSnackbar(
    message: string,
    tone: 'neutral' | 'success' | 'error' = 'neutral',
    actionLabel?: string,
    onAction?: () => void,
  ) {
    if (snackbarTimer.current) clearTimeout(snackbarTimer.current);
    setSnackbar({ message, tone, actionLabel, onAction });
    snackbarTimer.current = setTimeout(() => setSnackbar(null), actionLabel ? 5200 : 3400);
  }

  function openSourcePicker(kind: MediaKind, index?: number) {
    setInlineError(null);
    setSourceRequest({ kind, index });
  }

  async function chooseImage(source: 'library' | 'camera') {
    const request = sourceRequest;
    if (!request) return;
    setSourceRequest(null);

    try {
      if (source === 'camera') {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) {
          setInlineError({
            ...request,
            message: 'Cho phép quyền camera trong Cài đặt để chụp ảnh mới.',
          });
          return;
        }
      }

      const options: ImagePicker.ImagePickerOptions = {
        allowsEditing: request.kind !== 'wall',
        aspect: request.kind === 'avatar' ? [1, 1] : request.kind === 'cover' ? [16, 9] : undefined,
        exif: false,
        mediaTypes: ['images'],
        quality: 0.88,
      };

      const result = source === 'camera'
        ? await ImagePicker.launchCameraAsync(options)
        : await ImagePicker.launchImageLibraryAsync(options);

      if (result.canceled || !result.assets[0]?.uri) return;
      const asset = result.assets[0];
      const validationMessage = validateImage(asset, request.kind);

      if (validationMessage) {
        setInlineError({ ...request, message: validationMessage });
        showSnackbar(validationMessage, 'error');
        return;
      }

      setMedia(request, { uri: asset.uri, status: 'processing' });
      await delay(PROCESSING_DELAY_MS);
      setMedia(request, { uri: asset.uri, status: 'ready' });
      showSnackbar('Ảnh đã được thêm và tự động lưu.', 'success');
    } catch {
      setInlineError({ ...request, message: 'Không thể mở hoặc xử lý ảnh này. Hãy thử lại.' });
      showSnackbar('Không thể xử lý ảnh. Hãy thử lại.', 'error');
    }
  }

  function setMedia(request: Exclude<SourceRequest, null>, item: MediaItem | null) {
    if (request.kind === 'avatar') setAvatar(item);
    if (request.kind === 'cover') setCover(item);
    if (request.kind === 'wall' && request.index !== undefined) {
      setWallItems((current) => current.map((value, index) => (index === request.index ? item : value)));
    }
  }

  function removeWallImage(index: number) {
    const removed = wallItems[index];
    if (!removed) return;

    setWallItems((current) => current.map((item, itemIndex) => (itemIndex === index ? null : item)));
    showSnackbar('Đã xóa ảnh chia sẻ.', 'neutral', 'Hoàn tác', () => {
      setWallItems((current) => current.map((item, itemIndex) => (itemIndex === index ? removed : item)));
      setSnackbar(null);
    });
  }

  async function completeProfile(skipped: boolean) {
    try {
      const draft: StoredDraft = {
        avatarUri: avatar?.uri ?? null,
        coverUri: cover?.uri ?? null,
        wallUris: wallItems.map((item) => item?.uri ?? null),
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setCompleted(true);
      if (skipped && mediaCount === 0) {
        showSnackbar('Bạn có thể thêm ảnh bất cứ lúc nào trong Hồ sơ.', 'neutral');
      }
    } catch {
      showSnackbar('Không thể lưu hồ sơ lúc này. Hãy thử lại.', 'error');
    }
  }

  if (completed) {
    return (
      <CompletionState
        hasAvatar={Boolean(avatar)}
        mediaCount={mediaCount}
        onEdit={() => setCompleted(false)}
      />
    );
  }

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <LinearGradient colors={['#050712', '#070A16', '#050712']} style={StyleSheet.absoluteFill} />
      <View style={styles.singleGlow} />

      <SafeAreaView edges={['top', 'left', 'right', 'bottom']} style={styles.safeArea}>
        <View style={[styles.frame, { width: contentWidth }]}>
          <Header compact={compact} onBack={() => showSnackbar('Bản nháp đã được lưu tự động.')} />

          <ScrollView
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.hero}>
              <View style={styles.heroIcon}>
                <Ionicons name="images-outline" size={23} color={colors.violet} />
              </View>
              <Text accessibilityRole="header" style={[styles.heading, compact && styles.headingCompact]}>
                Thêm ảnh hồ sơ
              </Text>
              <Text style={styles.subtitle}>
                Dùng ảnh cá nhân hoặc avatar trong game mà đồng đội dễ nhận ra. Bạn có thể thay đổi bất cứ lúc nào.
              </Text>
            </View>

            <SectionCard>
              <SectionHeader
                title="Ảnh đại diện"
                description="Ảnh rõ giúp hồ sơ dễ nhận biết hơn khi ghép đội."
                status={<StatusPill tone={avatar ? 'complete' : 'recommended'} />}
              />

              <Pressable
                accessibilityHint="Mở lựa chọn camera hoặc thư viện ảnh"
                accessibilityLabel={avatar ? 'Ảnh đại diện đã được thêm. Nhấn để thay đổi.' : 'Thêm ảnh đại diện.'}
                accessibilityRole="button"
                accessibilityState={{ busy: avatar?.status === 'processing' }}
                onPress={() => openSourcePicker('avatar')}
                style={({ pressed }) => [styles.avatarSelector, pressed && styles.controlPressed]}
              >
                <View style={styles.avatarPreview}>
                  {avatar ? <Image source={{ uri: avatar.uri }} style={styles.avatarImage} /> : (
                    <Ionicons name="person-outline" size={32} color={colors.violet} />
                  )}
                  {avatar?.status === 'processing' ? (
                    <View style={styles.processingOverlay}>
                      <ActivityIndicator color="#FFFFFF" />
                    </View>
                  ) : null}
                </View>
                <View style={styles.selectorCopy}>
                  <Text style={styles.selectorTitle}>{avatar ? 'Ảnh đại diện đã sẵn sàng' : 'Chọn ảnh đại diện'}</Text>
                  <Text style={styles.selectorMeta}>Ảnh vuông · Tối đa 10 MB</Text>
                </View>
                <Ionicons name={avatar ? 'pencil-outline' : 'chevron-forward'} size={21} color={colors.textMuted} />
              </Pressable>
              <InlineErrorMessage error={inlineError?.kind === 'avatar' ? inlineError.message : null} />
            </SectionCard>

            <SectionCard>
              <SectionHeader
                title="Ảnh hồ sơ game"
                description="Thêm ảnh rank, nhân vật hoặc thành tích để đồng đội hiểu phong cách chơi của bạn."
                status={<StatusPill tone={cover ? 'complete' : 'optional'} />}
              />

              <Pressable
                accessibilityHint="Mở lựa chọn camera hoặc thư viện ảnh"
                accessibilityLabel={cover ? 'Ảnh hồ sơ game đã được thêm. Nhấn để thay đổi.' : 'Thêm ảnh hồ sơ game.'}
                accessibilityRole="button"
                accessibilityState={{ busy: cover?.status === 'processing' }}
                onPress={() => openSourcePicker('cover')}
                style={({ pressed }) => [styles.coverSelector, pressed && styles.controlPressed]}
              >
                {cover ? (
                  <>
                    <Image resizeMode="cover" source={{ uri: cover.uri }} style={styles.coverImage} />
                    <LinearGradient colors={['transparent', 'rgba(4, 6, 15, 0.82)']} style={StyleSheet.absoluteFill} />
                    <View style={styles.coverReadyRow}>
                      <View>
                        <Text style={styles.coverReadyTitle}>Ảnh đã sẵn sàng</Text>
                        <Text style={styles.coverReadyMeta}>Nhấn để thay ảnh</Text>
                      </View>
                      <View style={styles.editCircle}>
                        <Ionicons name="pencil-outline" size={18} color="#FFFFFF" />
                      </View>
                    </View>
                    {cover.status === 'processing' ? (
                      <View style={styles.processingOverlay}>
                        <ActivityIndicator color="#FFFFFF" />
                        <Text style={styles.processingText}>Đang xử lý ảnh…</Text>
                      </View>
                    ) : null}
                  </>
                ) : (
                  <View style={styles.coverEmpty}>
                    <View style={styles.coverIconBox}>
                      <MaterialCommunityIcons name="image-plus-outline" size={32} color={colors.violet} />
                    </View>
                    <Text style={styles.coverEmptyTitle}>Thêm ảnh hồ sơ game</Text>
                    <Text style={styles.coverEmptyMeta}>Khung ngang 16:9 · Tối đa 10 MB</Text>
                  </View>
                )}
              </Pressable>
              <InlineErrorMessage error={inlineError?.kind === 'cover' ? inlineError.message : null} />
            </SectionCard>

            <SectionCard>
              <Pressable
                accessibilityLabel={`Ảnh chia sẻ, đã thêm ${wallCount} trên 4 ảnh`}
                accessibilityRole="button"
                accessibilityState={{ expanded: galleryExpanded }}
                onPress={() => setGalleryExpanded((value) => !value)}
                style={({ pressed }) => [styles.galleryHeader, pressed && styles.controlPressed]}
              >
                <View style={styles.galleryHeaderIcon}>
                  <Ionicons name="grid-outline" size={21} color={colors.violet} />
                </View>
                <View style={styles.galleryHeaderCopy}>
                  <Text style={styles.galleryTitle}>Ảnh chia sẻ</Text>
                  <Text style={styles.galleryDescription}>Tùy chọn · {wallCount}/4 ảnh</Text>
                </View>
                <Ionicons
                  name={galleryExpanded ? 'chevron-up' : 'chevron-down'}
                  size={21}
                  color={colors.textMuted}
                />
              </Pressable>

              {galleryExpanded ? (
                <View style={styles.galleryContent}>
                  <Text style={styles.galleryHelper}>
                    Chia sẻ khoảnh khắc chơi game. Phần này có thể hoàn thiện sau trong Hồ sơ.
                  </Text>
                  <View style={styles.galleryGrid}>
                    {wallItems.map((item, index) => (
                      <GalleryTile
                        index={index}
                        key={index}
                        onPress={() => openSourcePicker('wall', index)}
                        onRemove={item ? () => removeWallImage(index) : undefined}
                        uri={item?.uri}
                      />
                    ))}
                  </View>
                  <InlineErrorMessage error={inlineError?.kind === 'wall' ? inlineError.message : null} />
                </View>
              ) : null}
            </SectionCard>

            <View style={styles.privacyCard}>
              <View style={styles.privacyIcon}>
                <Ionicons name="shield-checkmark-outline" size={25} color={colors.success} />
              </View>
              <View style={styles.privacyCopy}>
                <Text style={styles.privacyTitle}>Bạn kiểm soát ảnh của mình</Text>
                <Text style={styles.privacyText}>
                  Ảnh hiển thị cho thành viên Liqi Match. Bạn có thể thay đổi hoặc xóa bất cứ lúc nào trong cài đặt hồ sơ.
                </Text>
              </View>
            </View>
          </ScrollView>

          <View style={styles.stickyAction}>
            <View style={styles.actionSummary}>
              <Text style={styles.actionSummaryTitle}>{mediaCount > 0 ? `${mediaCount} ảnh đã sẵn sàng` : 'Ảnh có thể thêm sau'}</Text>
              <Text style={styles.actionSummaryText}>Bản nháp được lưu tự động</Text>
            </View>
            <GradientButton
              accessibilityHint="Lưu lựa chọn và kết thúc thiết lập hồ sơ"
              label="Hoàn tất hồ sơ"
              onPress={() => completeProfile(false)}
            />
            <Pressable
              accessibilityRole="button"
              onPress={() => completeProfile(true)}
              style={({ pressed }) => [styles.laterButton, pressed && styles.laterPressed]}
            >
              <Text style={styles.laterText}>Làm sau</Text>
            </Pressable>
          </View>
        </View>

        <Snackbar
          actionLabel={snackbar?.actionLabel}
          message={snackbar?.message ?? null}
          onAction={snackbar?.onAction}
          tone={snackbar?.tone}
        />

        <SourcePickerSheet
          onCamera={() => chooseImage('camera')}
          onClose={() => setSourceRequest(null)}
          onLibrary={() => chooseImage('library')}
          title={sourceTitle(sourceRequest)}
          visible={Boolean(sourceRequest)}
        />
      </SafeAreaView>
    </View>
  );
}

function Header({ compact, onBack }: { compact: boolean; onBack: () => void }) {
  return (
    <View style={styles.topBar}>
      <Pressable
        accessibilityLabel="Quay lại bước trước"
        accessibilityRole="button"
        hitSlop={4}
        onPress={onBack}
        style={({ pressed }) => [styles.roundButton, pressed && styles.controlPressed]}
      >
        <Ionicons name="chevron-back" size={25} color={colors.text} />
      </Pressable>

      <View accessibilityLabel="Liqi Match" style={styles.brandRow}>
        <Text style={[styles.brandAccent, compact && styles.brandCompact]}>Liqi</Text>
        <Text style={[styles.brandText, compact && styles.brandCompact]}> Match</Text>
      </View>

      <View accessibilityLabel="Bước 5 trên 5" style={styles.stepBadge}>
        <Text style={styles.stepLabel}>Bước</Text>
        <Text style={styles.stepText}>5/5</Text>
      </View>
    </View>
  );
}

function SectionCard({ children }: { children: React.ReactNode }) {
  return <View style={styles.sectionCard}>{children}</View>;
}

function SectionHeader({
  title,
  description,
  status,
}: {
  title: string;
  description: string;
  status: React.ReactNode;
}) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionHeaderCopy}>
        <Text accessibilityRole="header" style={styles.sectionTitle}>{title}</Text>
        <Text style={styles.sectionDescription}>{description}</Text>
      </View>
      {status}
    </View>
  );
}

function InlineErrorMessage({ error }: { error: string | null }) {
  if (!error) return null;
  return (
    <View accessibilityLiveRegion="assertive" style={styles.errorRow}>
      <Ionicons name="alert-circle-outline" size={18} color={colors.danger} />
      <Text style={styles.errorText}>{error}</Text>
    </View>
  );
}

function CompletionState({
  hasAvatar,
  mediaCount,
  onEdit,
}: {
  hasAvatar: boolean;
  mediaCount: number;
  onEdit: () => void;
}) {
  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <LinearGradient colors={['#050712', '#0B0C1C', '#050712']} style={StyleSheet.absoluteFill} />
      <View style={styles.completionGlow} />
      <SafeAreaView style={styles.completionSafeArea}>
        <View style={styles.completionContent}>
          <View style={styles.successIcon}>
            <Ionicons name="checkmark" size={38} color="#06120B" />
          </View>
          <Text accessibilityRole="header" style={styles.completionTitle}>Hồ sơ đã sẵn sàng</Text>
          <Text style={styles.completionText}>
            {mediaCount > 0
              ? `Đã lưu ${mediaCount} ảnh. Bạn có thể tiếp tục vào Liqi Match và chỉnh sửa bất cứ lúc nào.`
              : 'Bạn có thể bắt đầu ngay và bổ sung ảnh sau trong phần Hồ sơ.'}
          </Text>

          <View style={styles.completionChecklist}>
            <CompletionRow complete label="Thiết lập ghép đội" />
            <CompletionRow complete={hasAvatar} label="Ảnh đại diện" optional />
            <CompletionRow complete={mediaCount > Number(hasAvatar)} label="Ảnh phong cách chơi" optional />
          </View>

          <GradientButton label="Vào Liqi Match" onPress={() => undefined} />
          <Pressable accessibilityRole="button" onPress={onEdit} style={styles.editProfileButton}>
            <Text style={styles.editProfileText}>Quay lại chỉnh ảnh</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    </View>
  );
}

function CompletionRow({ complete, label, optional = false }: { complete: boolean; label: string; optional?: boolean }) {
  return (
    <View style={styles.completionRow}>
      <Ionicons
        name={complete ? 'checkmark-circle' : 'ellipse-outline'}
        size={21}
        color={complete ? colors.success : colors.textMuted}
      />
      <Text style={styles.completionRowLabel}>{label}</Text>
      {optional ? <Text style={styles.completionOptional}>Tùy chọn</Text> : null}
    </View>
  );
}

function sourceTitle(request: SourceRequest) {
  if (request?.kind === 'avatar') return 'Thêm ảnh đại diện';
  if (request?.kind === 'cover') return 'Thêm ảnh hồ sơ game';
  return 'Thêm ảnh chia sẻ';
}

function validateImage(asset: ImagePicker.ImagePickerAsset, kind: MediaKind): string | null {
  if (asset.fileSize && asset.fileSize > MAX_FILE_BYTES) {
    return 'Ảnh lớn hơn 10 MB. Hãy chọn ảnh có dung lượng nhỏ hơn.';
  }

  const width = asset.width ?? 0;
  const height = asset.height ?? 0;

  if (kind === 'avatar' && (width < 320 || height < 320)) {
    return 'Ảnh đại diện quá nhỏ. Hãy chọn ảnh ít nhất 320 × 320 px.';
  }

  if (kind === 'cover' && (width < 800 || height < 450)) {
    return 'Ảnh hồ sơ game quá nhỏ. Hãy chọn ảnh ít nhất 800 × 450 px.';
  }

  if (kind === 'wall' && (width < 480 || height < 320)) {
    return 'Ảnh chia sẻ quá nhỏ. Hãy chọn ảnh ít nhất 480 × 320 px.';
  }

  return null;
}

function delay(milliseconds: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, milliseconds));
}

const styles = StyleSheet.create({
  root: {
    backgroundColor: colors.background,
    flex: 1,
  },
  safeArea: {
    alignItems: 'center',
    flex: 1,
  },
  frame: {
    flex: 1,
  },
  singleGlow: {
    backgroundColor: 'rgba(119, 58, 255, 0.13)',
    borderRadius: 300,
    height: 600,
    position: 'absolute',
    right: -420,
    top: 80,
    width: 600,
  },
  topBar: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    minHeight: 62,
    paddingHorizontal: 16,
  },
  roundButton: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.035)',
    borderColor: colors.border,
    borderRadius: 23,
    borderWidth: 1,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  brandRow: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  brandAccent: {
    color: colors.violet,
    fontSize: 23,
    fontStyle: 'italic',
    fontWeight: '800',
    letterSpacing: -1,
  },
  brandText: {
    color: colors.text,
    fontSize: 23,
    fontStyle: 'italic',
    fontWeight: '800',
    letterSpacing: -1,
  },
  brandCompact: {
    fontSize: 20,
  },
  stepBadge: {
    alignItems: 'baseline',
    backgroundColor: 'rgba(255,255,255,0.035)',
    borderColor: colors.border,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 4,
    minHeight: 46,
    justifyContent: 'center',
    paddingHorizontal: 11,
  },
  stepLabel: {
    color: colors.textMuted,
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  stepText: {
    color: colors.violet,
    fontSize: 16,
    fontWeight: '800',
  },
  scrollContent: {
    paddingBottom: 196,
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  hero: {
    alignItems: 'center',
    marginBottom: 26,
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  heroIcon: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.10)',
    borderColor: 'rgba(169, 112, 255, 0.18)',
    borderRadius: 20,
    borderWidth: 1,
    height: 40,
    justifyContent: 'center',
    marginBottom: 12,
    width: 40,
  },
  heading: {
    color: colors.text,
    fontSize: 30,
    fontWeight: '800',
    letterSpacing: -0.9,
    textAlign: 'center',
  },
  headingCompact: {
    fontSize: 27,
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 14.5,
    lineHeight: 21,
    marginTop: 9,
    maxWidth: 530,
    textAlign: 'center',
  },
  sectionCard: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 18,
    padding: 16,
  },
  sectionHeader: {
    alignItems: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionHeaderCopy: {
    flex: 1,
    minWidth: 210,
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  sectionDescription: {
    color: colors.textSecondary,
    fontSize: 13.5,
    lineHeight: 19,
    marginTop: 5,
  },
  avatarSelector: {
    alignItems: 'center',
    backgroundColor: colors.backgroundRaised,
    borderColor: colors.border,
    borderRadius: 17,
    borderWidth: 1,
    flexDirection: 'row',
    minHeight: 112,
    padding: 13,
  },
  avatarPreview: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.08)',
    borderColor: 'rgba(169, 112, 255, 0.25)',
    borderRadius: 43,
    borderWidth: 1,
    height: 86,
    justifyContent: 'center',
    overflow: 'hidden',
    width: 86,
  },
  avatarImage: {
    height: '100%',
    width: '100%',
  },
  selectorCopy: {
    flex: 1,
    marginHorizontal: 14,
  },
  selectorTitle: {
    color: colors.text,
    fontSize: 15.5,
    fontWeight: '700',
  },
  selectorMeta: {
    color: colors.textMuted,
    fontSize: 12.5,
    lineHeight: 18,
    marginTop: 4,
  },
  coverSelector: {
    aspectRatio: 16 / 7.1,
    backgroundColor: colors.backgroundRaised,
    borderColor: colors.border,
    borderRadius: 17,
    borderWidth: 1,
    justifyContent: 'center',
    minHeight: 160,
    overflow: 'hidden',
  },
  coverEmpty: {
    alignItems: 'center',
    padding: 20,
  },
  coverIconBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.09)',
    borderRadius: 16,
    height: 54,
    justifyContent: 'center',
    marginBottom: 11,
    width: 54,
  },
  coverEmptyTitle: {
    color: colors.text,
    fontSize: 15.5,
    fontWeight: '700',
  },
  coverEmptyMeta: {
    color: colors.textMuted,
    fontSize: 12.5,
    marginTop: 5,
  },
  coverImage: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  coverReadyRow: {
    alignItems: 'center',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    left: 0,
    padding: 14,
    position: 'absolute',
    right: 0,
  },
  coverReadyTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '700',
  },
  coverReadyMeta: {
    color: '#D1D4E2',
    fontSize: 12,
    marginTop: 2,
  },
  editCircle: {
    alignItems: 'center',
    backgroundColor: 'rgba(12, 15, 31, 0.82)',
    borderColor: 'rgba(255,255,255,0.20)',
    borderRadius: 18,
    borderWidth: 1,
    height: 36,
    justifyContent: 'center',
    width: 36,
  },
  processingOverlay: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
    alignItems: 'center',
    backgroundColor: 'rgba(4, 6, 16, 0.64)',
    gap: 8,
    justifyContent: 'center',
  },
  processingText: {
    color: colors.text,
    fontSize: 12.5,
    fontWeight: '600',
  },
  galleryHeader: {
    alignItems: 'center',
    borderRadius: 14,
    flexDirection: 'row',
    minHeight: 58,
    paddingVertical: 4,
  },
  galleryHeaderIcon: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.09)',
    borderRadius: 13,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  galleryHeaderCopy: {
    flex: 1,
    marginHorizontal: 12,
  },
  galleryTitle: {
    color: colors.text,
    fontSize: 16.5,
    fontWeight: '700',
  },
  galleryDescription: {
    color: colors.textMuted,
    fontSize: 12.5,
    marginTop: 3,
  },
  galleryContent: {
    borderTopColor: colors.border,
    borderTopWidth: 1,
    marginTop: 13,
    paddingTop: 14,
  },
  galleryHelper: {
    color: colors.textSecondary,
    fontSize: 13,
    lineHeight: 19,
    marginBottom: 13,
  },
  galleryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  errorRow: {
    alignItems: 'flex-start',
    backgroundColor: 'rgba(255, 119, 155, 0.08)',
    borderColor: 'rgba(255, 119, 155, 0.20)',
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 8,
    marginTop: 11,
    padding: 11,
  },
  errorText: {
    color: '#FFB2C6',
    flex: 1,
    fontSize: 12.5,
    lineHeight: 18,
  },
  privacyCard: {
    alignItems: 'flex-start',
    backgroundColor: 'rgba(112, 227, 163, 0.045)',
    borderColor: 'rgba(112, 227, 163, 0.17)',
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 13,
    marginBottom: 10,
    padding: 15,
  },
  privacyIcon: {
    alignItems: 'center',
    backgroundColor: 'rgba(112, 227, 163, 0.09)',
    borderRadius: 14,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  privacyCopy: {
    flex: 1,
  },
  privacyTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '700',
  },
  privacyText: {
    color: colors.textSecondary,
    fontSize: 12.8,
    lineHeight: 18.5,
    marginTop: 4,
  },
  stickyAction: {
    backgroundColor: 'rgba(7, 9, 20, 0.97)',
    borderTopColor: colors.border,
    borderTopWidth: 1,
    bottom: 0,
    left: 0,
    paddingBottom: Platform.select({ ios: 4, default: 8 }),
    paddingHorizontal: 16,
    paddingTop: 10,
    position: 'absolute',
    right: 0,
  },
  actionSummary: {
    alignItems: 'baseline',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  actionSummaryTitle: {
    color: colors.textSecondary,
    fontSize: 12.5,
    fontWeight: '600',
  },
  actionSummaryText: {
    color: colors.textMuted,
    fontSize: 11.5,
  },
  laterButton: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
    marginTop: 2,
  },
  laterPressed: {
    opacity: 0.66,
  },
  laterText: {
    color: colors.textSecondary,
    fontSize: 14.5,
    fontWeight: '600',
  },
  controlPressed: {
    backgroundColor: colors.surfacePressed,
    opacity: 0.90,
  },
  completionGlow: {
    backgroundColor: 'rgba(91, 231, 157, 0.11)',
    borderRadius: 300,
    height: 600,
    left: -360,
    position: 'absolute',
    top: 20,
    width: 600,
  },
  completionSafeArea: {
    flex: 1,
    justifyContent: 'center',
  },
  completionContent: {
    alignSelf: 'center',
    maxWidth: 520,
    paddingHorizontal: 24,
    width: '100%',
  },
  successIcon: {
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: colors.success,
    borderRadius: 34,
    height: 68,
    justifyContent: 'center',
    marginBottom: 20,
    shadowColor: colors.success,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 18,
    width: 68,
  },
  completionTitle: {
    color: colors.text,
    fontSize: 30,
    fontWeight: '800',
    letterSpacing: -0.8,
    textAlign: 'center',
  },
  completionText: {
    color: colors.textSecondary,
    fontSize: 14.5,
    lineHeight: 21,
    marginTop: 9,
    textAlign: 'center',
  },
  completionChecklist: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: 18,
    borderWidth: 1,
    marginBottom: 24,
    marginTop: 24,
    padding: 8,
  },
  completionRow: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 48,
    paddingHorizontal: 9,
  },
  completionRowLabel: {
    color: colors.text,
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 10,
  },
  completionOptional: {
    color: colors.textMuted,
    fontSize: 12,
  },
  editProfileButton: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    marginTop: 8,
  },
  editProfileText: {
    color: colors.textSecondary,
    fontSize: 14.5,
    fontWeight: '600',
  },
});
