import { Ionicons } from '@expo/vector-icons';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';

type Props = {
  uri?: string;
  index: number;
  onPress: () => void;
  onRemove?: () => void;
};

export function GalleryTile({ uri, index, onPress, onRemove }: Props) {
  const position = index + 1;

  return (
    <Pressable
      accessibilityHint={uri ? 'Mở trình chọn để thay ảnh' : 'Mở trình chọn ảnh'}
      accessibilityLabel={uri ? `Ảnh chia sẻ số ${position} đã được thêm` : `Thêm ảnh chia sẻ số ${position}`}
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.tile, pressed && styles.pressed]}
    >
      {uri ? (
        <>
          <Image source={{ uri }} style={styles.image} />
          <View style={styles.imageOverlay} />
          <View style={styles.changeBadge}>
            <Ionicons name="images-outline" size={15} color="#FFFFFF" />
            <Text style={styles.changeText}>Thay ảnh</Text>
          </View>
          {onRemove ? (
            <Pressable
              accessibilityLabel={`Xóa ảnh chia sẻ số ${position}`}
              accessibilityRole="button"
              hitSlop={10}
              onPress={(event) => {
                event.stopPropagation();
                onRemove();
              }}
              style={styles.removeTouchTarget}
            >
              <View style={styles.removeVisual}>
                <Ionicons name="close" size={18} color="#FFFFFF" />
              </View>
            </Pressable>
          ) : null}
        </>
      ) : (
        <View style={styles.emptyContent}>
          <View style={styles.plusCircle}>
            <Ionicons name="add" size={25} color={colors.violet} />
          </View>
          <Text style={styles.label}>Thêm ảnh</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    alignItems: 'center',
    aspectRatio: 1.25,
    backgroundColor: 'rgba(255,255,255,0.025)',
    borderColor: colors.border,
    borderRadius: 14,
    borderWidth: 1,
    flexBasis: '47%',
    flexGrow: 1,
    justifyContent: 'center',
    minHeight: 112,
    overflow: 'hidden',
  },
  emptyContent: {
    alignItems: 'center',
    gap: 9,
  },
  image: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  imageOverlay: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
    backgroundColor: 'rgba(3, 5, 16, 0.22)',
  },
  plusCircle: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.10)',
    borderRadius: 21,
    height: 42,
    justifyContent: 'center',
    width: 42,
  },
  label: {
    color: colors.textSecondary,
    fontSize: 13.5,
    fontWeight: '600',
  },
  changeBadge: {
    alignItems: 'center',
    backgroundColor: 'rgba(8, 11, 29, 0.78)',
    borderColor: 'rgba(255,255,255,0.16)',
    borderRadius: 9,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 6,
  },
  changeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  removeTouchTarget: {
    alignItems: 'center',
    height: 48,
    justifyContent: 'center',
    position: 'absolute',
    right: 1,
    top: 1,
    width: 48,
  },
  removeVisual: {
    alignItems: 'center',
    backgroundColor: 'rgba(8, 11, 29, 0.86)',
    borderColor: 'rgba(255,255,255,0.18)',
    borderRadius: 15,
    borderWidth: 1,
    height: 30,
    justifyContent: 'center',
    width: 30,
  },
  pressed: {
    backgroundColor: colors.surfacePressed,
    borderColor: colors.borderStrong,
    opacity: 0.92,
  },
});
