import { Ionicons } from '@expo/vector-icons';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';

type Props = {
  visible: boolean;
  title: string;
  onClose: () => void;
  onCamera: () => void;
  onLibrary: () => void;
};

export function SourcePickerSheet({ visible, title, onClose, onCamera, onLibrary }: Props) {
  return (
    <Modal
      animationType="fade"
      onRequestClose={onClose}
      presentationStyle="overFullScreen"
      statusBarTranslucent
      transparent
      visible={visible}
    >
      <Pressable accessibilityRole="button" onPress={onClose} style={styles.backdrop}>
        <SafeAreaView edges={['bottom']} style={styles.safeArea}>
          <Pressable
            accessibilityViewIsModal
            onPress={(event) => event.stopPropagation()}
            style={styles.sheet}
          >
            <View style={styles.handle} />
            <Text accessibilityRole="header" style={styles.title}>{title}</Text>
            <Text style={styles.subtitle}>Chọn cách bạn muốn thêm ảnh.</Text>

            <View style={styles.actions}>
              <SourceAction
                icon="images-outline"
                label="Chọn từ thư viện"
                description="Chỉ ảnh bạn chọn được chia sẻ với ứng dụng"
                onPress={onLibrary}
              />
              <SourceAction
                icon="camera-outline"
                label="Chụp ảnh mới"
                description="Ứng dụng sẽ xin quyền camera khi cần"
                onPress={onCamera}
              />
            </View>

            <Pressable accessibilityRole="button" onPress={onClose} style={styles.cancelButton}>
              <Text style={styles.cancelText}>Hủy</Text>
            </Pressable>
          </Pressable>
        </SafeAreaView>
      </Pressable>
    </Modal>
  );
}

type SourceActionProps = {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  description: string;
  onPress: () => void;
};

function SourceAction({ icon, label, description, onPress }: SourceActionProps) {
  return (
    <Pressable
      accessibilityHint={description}
      accessibilityLabel={label}
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.action, pressed && styles.actionPressed]}
    >
      <View style={styles.iconBox}>
        <Ionicons name={icon} size={23} color={colors.violet} />
      </View>
      <View style={styles.actionCopy}>
        <Text style={styles.actionLabel}>{label}</Text>
        <Text style={styles.actionDescription}>{description}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    backgroundColor: colors.overlay,
    flex: 1,
    justifyContent: 'flex-end',
  },
  safeArea: {
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: '#111625',
    borderColor: colors.border,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    paddingBottom: 14,
    paddingHorizontal: 18,
    paddingTop: 10,
  },
  handle: {
    alignSelf: 'center',
    backgroundColor: 'rgba(255,255,255,0.20)',
    borderRadius: 2,
    height: 4,
    marginBottom: 16,
    width: 38,
  },
  title: {
    color: colors.text,
    fontSize: 21,
    fontWeight: '700',
  },
  subtitle: {
    color: colors.textMuted,
    fontSize: 14,
    lineHeight: 20,
    marginTop: 4,
  },
  actions: {
    gap: 10,
    marginTop: 18,
  },
  action: {
    alignItems: 'center',
    backgroundColor: colors.surfaceElevated,
    borderColor: colors.border,
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: 'row',
    minHeight: 74,
    paddingHorizontal: 13,
    paddingVertical: 11,
  },
  actionPressed: {
    backgroundColor: colors.surfacePressed,
  },
  iconBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(169, 112, 255, 0.11)',
    borderRadius: 13,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  actionCopy: {
    flex: 1,
    marginHorizontal: 12,
  },
  actionLabel: {
    color: colors.text,
    fontSize: 15.5,
    fontWeight: '700',
  },
  actionDescription: {
    color: colors.textMuted,
    fontSize: 12.5,
    lineHeight: 17,
    marginTop: 3,
  },
  cancelButton: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    marginTop: 10,
  },
  cancelText: {
    color: colors.textSecondary,
    fontSize: 15.5,
    fontWeight: '600',
  },
});
