import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';

type Props = {
  message: string | null;
  actionLabel?: string;
  onAction?: () => void;
  tone?: 'neutral' | 'success' | 'error';
};

export function Snackbar({ message, actionLabel, onAction, tone = 'neutral' }: Props) {
  if (!message) return null;

  const icon = tone === 'success'
    ? 'checkmark-circle-outline'
    : tone === 'error'
      ? 'alert-circle-outline'
      : 'information-circle-outline';

  return (
    <View accessibilityLiveRegion="polite" style={styles.wrapper}>
      <Ionicons
        name={icon}
        size={20}
        color={tone === 'success' ? colors.success : tone === 'error' ? colors.danger : colors.textSecondary}
      />
      <Text style={styles.message}>{message}</Text>
      {actionLabel && onAction ? (
        <Pressable accessibilityRole="button" onPress={onAction} style={styles.action}>
          <Text style={styles.actionText}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    backgroundColor: '#171C2B',
    borderColor: colors.border,
    borderRadius: 14,
    borderWidth: 1,
    bottom: 104,
    flexDirection: 'row',
    gap: 9,
    left: 16,
    minHeight: 50,
    paddingHorizontal: 14,
    position: 'absolute',
    right: 16,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 12,
    zIndex: 50,
  },
  message: {
    color: colors.text,
    flex: 1,
    fontSize: 13.5,
    lineHeight: 19,
  },
  action: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
    paddingHorizontal: 4,
  },
  actionText: {
    color: colors.violet,
    fontSize: 13.5,
    fontWeight: '700',
  },
});
