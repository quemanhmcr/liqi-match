import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';

type Tone = 'optional' | 'recommended' | 'complete';

type Props = {
  tone: Tone;
};

const config: Record<Tone, { label: string; icon: keyof typeof Ionicons.glyphMap }> = {
  optional: { label: 'Tùy chọn', icon: 'ellipse-outline' },
  recommended: { label: 'Khuyến nghị', icon: 'sparkles-outline' },
  complete: { label: 'Đã thêm', icon: 'checkmark-circle-outline' },
};

export function StatusPill({ tone }: Props) {
  const item = config[tone];
  return (
    <View style={[styles.pill, tone === 'complete' && styles.completePill]}>
      <Ionicons
        name={item.icon}
        size={14}
        color={tone === 'complete' ? colors.success : colors.violet}
      />
      <Text style={[styles.text, tone === 'complete' && styles.completeText]}>{item.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(169, 112, 255, 0.10)',
    borderColor: 'rgba(169, 112, 255, 0.22)',
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 6,
    minHeight: 30,
    paddingHorizontal: 10,
  },
  completePill: {
    backgroundColor: 'rgba(112, 227, 163, 0.09)',
    borderColor: 'rgba(112, 227, 163, 0.23)',
  },
  text: {
    color: '#CDB8F7',
    fontSize: 12.5,
    fontWeight: '600',
  },
  completeText: {
    color: '#A9EDC8',
  },
});
