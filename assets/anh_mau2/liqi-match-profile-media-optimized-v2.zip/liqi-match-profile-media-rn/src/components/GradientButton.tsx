import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';

type Props = {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  accessibilityHint?: string;
};

export function GradientButton({
  label,
  onPress,
  disabled = false,
  loading = false,
  accessibilityHint,
}: Props) {
  const inactive = disabled || loading;

  return (
    <Pressable
      accessibilityHint={accessibilityHint}
      accessibilityLabel={label}
      accessibilityRole="button"
      accessibilityState={{ disabled: inactive, busy: loading }}
      disabled={inactive}
      onPress={onPress}
      style={({ pressed }) => [
        styles.wrapper,
        pressed && !inactive && styles.pressed,
        inactive && styles.disabled,
      ]}
    >
      <LinearGradient
        colors={inactive ? ['#403552', '#27334A'] : ['#B84DFF', '#754AFF', '#2F82FF']}
        end={{ x: 1, y: 0.5 }}
        start={{ x: 0, y: 0.5 }}
        style={styles.gradient}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <>
            <Text allowFontScaling style={styles.label}>{label}</Text>
            <View style={styles.iconCircle}>
              <Ionicons name="arrow-forward" size={20} color="#4D5FC5" />
            </View>
          </>
        )}
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: 17,
    minHeight: 56,
    shadowColor: '#754AFF',
    shadowOffset: { width: 0, height: 7 },
    shadowOpacity: 0.24,
    shadowRadius: 14,
    elevation: 7,
  },
  gradient: {
    alignItems: 'center',
    borderColor: 'rgba(255,255,255,0.20)',
    borderRadius: 17,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    minHeight: 56,
    paddingHorizontal: 18,
  },
  label: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  iconCircle: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.90)',
    borderRadius: 17,
    height: 34,
    justifyContent: 'center',
    marginLeft: 12,
    width: 34,
  },
  pressed: {
    opacity: 0.90,
    transform: [{ scale: 0.99 }],
  },
  disabled: {
    opacity: 0.62,
    shadowOpacity: 0,
  },
});
