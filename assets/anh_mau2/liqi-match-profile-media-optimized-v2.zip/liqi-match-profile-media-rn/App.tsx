import { SafeAreaProvider } from 'react-native-safe-area-context';
import ProfileMediaScreen from './src/screens/ProfileMediaScreen';

export default function App() {
  return (
    <SafeAreaProvider>
      <ProfileMediaScreen />
    </SafeAreaProvider>
  );
}
