# QA Report – v2.0.0

## Passed

- `npx expo install --check`
- `npm run typecheck`
- `npm run export:android`
- Không còn `Alert` trong luồng media.
- Không còn placeholder cover giả dữ liệu người dùng.
- Không còn khai báo thủ công `READ_MEDIA_IMAGES`.
- Không còn copy “bắt buộc” hoặc “bảo mật tuyệt đối” trong UI.
- Các nút xóa ảnh có touch target 48 × 48.
- Các control chính có accessibility role, label, state hoặc live region phù hợp.
- Draft media được lưu và khôi phục bằng AsyncStorage.

## Integration notes

- Nút “Vào Liqi Match” là điểm nối demo; cần nối navigation thật.
- URI ảnh hiện là URI local; cần upload và đồng bộ với backend.
- Processing delay hiện mô phỏng bước xử lý local; thay bằng upload progress thật khi tích hợp API.
- Privacy visibility trong UI phải khớp authorization policy của backend.

## Dependency audit

`npm audit` ghi nhận các cảnh báo mức moderate trong chuỗi công cụ Expo/CLI, không có cảnh báo high hoặc critical. Không dùng `npm audit fix --force` để tránh nâng phiên bản phá vỡ Expo SDK hiện tại.
