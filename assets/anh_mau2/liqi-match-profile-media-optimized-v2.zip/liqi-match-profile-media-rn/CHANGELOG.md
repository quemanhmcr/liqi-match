# Changelog

## 2.0.0

- Refactor toàn bộ media onboarding theo activation-first UX.
- Chuyển avatar từ bắt buộc sang khuyến nghị.
- Bỏ cover mẫu gây false completion.
- Thêm bottom sheet chọn nguồn ảnh.
- Thêm validation file size và kích thước.
- Thêm autosave draft bằng AsyncStorage.
- Thêm inline error, processing state, snackbar và undo.
- Thu gọn gallery tùy chọn.
- Thêm sticky completion CTA và completion state.
- Cải thiện accessibility và touch targets.
- Giảm glow, nested card và visual noise.
- Loại quyền READ_MEDIA_IMAGES khai báo thủ công trên Android.
