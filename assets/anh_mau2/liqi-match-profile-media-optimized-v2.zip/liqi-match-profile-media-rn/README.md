# Liqi Match – Profile Media (Optimized v2)

Phiên bản React Native/Expo đã được refactor theo hướng premium, rõ trạng thái, giảm ma sát onboarding và hỗ trợ accessibility tốt hơn.

## Các thay đổi UX chính

- Avatar là **khuyến nghị**, không còn mâu thuẫn giữa “bắt buộc” và “làm sau”.
- Ảnh hồ sơ game và ảnh chia sẻ là **tùy chọn**.
- Không dùng ảnh cover mẫu gây hiểu nhầm là người dùng đã tải ảnh.
- Header hiển thị rõ **“Bước 5/5”**, không diễn đạt như trạng thái đã hoàn tất.
- Gallery được thu gọn mặc định để giảm tải nhận thức ở bước cuối.
- CTA chính cố định ở đáy, dùng copy theo kết quả: **“Hoàn tất hồ sơ”**.
- Privacy copy mô tả khả năng hiển thị, thay đổi và xóa ảnh; không dùng cam kết tuyệt đối.
- Nguồn ảnh được chọn bằng bottom sheet thay vì chuỗi Alert gây gián đoạn.
- Chọn ảnh từ thư viện không yêu cầu quyền truy cập toàn bộ thư viện trước.
- Camera chỉ xin quyền đúng lúc người dùng chọn chụp ảnh.
- Có validation dung lượng tối đa 10 MB và độ phân giải tối thiểu theo từng loại ảnh.
- Có trạng thái xử lý, inline error, snackbar, hoàn tác khi xóa ảnh và màn hình hoàn tất.
- Bản nháp được tự động lưu bằng AsyncStorage.
- Touch target, accessibility label/role/state và live-region đã được bổ sung.
- Visual được tiết chế: một vùng glow chính, ít border lồng nhau, spacing rộng và hierarchy rõ hơn.

## Quy tắc ảnh

- Ảnh đại diện: tối thiểu `320 × 320 px`, tối đa `10 MB`.
- Ảnh hồ sơ game: tối thiểu `800 × 450 px`, tối đa `10 MB`.
- Ảnh chia sẻ: tối thiểu `480 × 320 px`, tối đa `10 MB`.
- App chấp nhận ảnh người dùng chọn; việc chuẩn hóa định dạng nên được xử lý ở upload/backend trong sản phẩm thật.

## Chạy project

```bash
npm install
npx expo start
```

## Kiểm tra đã thực hiện

```bash
npm run typecheck
npm run export:android
```

Cả TypeScript strict check và Expo Android export đều chạy thành công trước khi đóng gói.

## File chính

- `src/screens/ProfileMediaScreen.tsx`
- `src/components/SourcePickerSheet.tsx`
- `src/components/GalleryTile.tsx`
- `src/components/GradientButton.tsx`
- `src/components/StatusPill.tsx`
- `src/components/Snackbar.tsx`
- `src/theme/colors.ts`

## Điểm cần nối khi tích hợp sản phẩm thật

- Thay completion demo bằng navigation thật.
- Upload URI cục bộ lên object storage/backend.
- Thêm upload progress theo byte, retry và content moderation từ API thật.
- Gắn analytics cho view, upload start/success/failure, skip và completion.
- Đồng bộ privacy scope với chính sách và backend authorization thực tế.
